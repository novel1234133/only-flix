# Only Flix — Full Admin OTT Store

## Run locally
1. Install Node.js 18+.
2. Extract the ZIP.
3. Open a terminal in the project folder.
4. Run `npm install`
5. Run `npm start`
6. Open `http://localhost:3000`
7. Admin: `http://localhost:3000/admin`

Default admin:
- Username: `admin`
- Password: `change-me-now`

## IMPORTANT BEFORE DEPLOYING
Set these environment variables:
- `ADMIN_USER`
- `ADMIN_PASS`
- `SESSION_SECRET`
- `PORT` (optional)

Example:
`ADMIN_USER=myadmin ADMIN_PASS=use-a-strong-password SESSION_SECRET=long-random-secret npm start`

## Included
- Public OTT storefront
- Product/service management
- Price and duration editing
- Order creation
- Order status management
- Store settings
- WhatsApp order flow
- Responsive UI
- JSON database for this starter version

For production, move data to a real database, enable HTTPS, add CSRF protection/rate limiting, and use a proper payment gateway. Verify that every subscription/account you sell is authorized and complies with the provider's terms.
